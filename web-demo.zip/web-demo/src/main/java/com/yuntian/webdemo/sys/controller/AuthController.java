package com.yuntian.webdemo.sys.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author yuntian
 * @date 2020/3/18 0018 23:06
 * @description
 */
@RestController
public class AuthController {


    @RequestMapping("/login")
    public void  login(){

    }


}
