package com.yuntian.webdemo.entity;

/**
 * @author guangleilei.
 * @date Created in 13:58 2020/1/13
 * @description
 */
public class GoodSKU {
}
