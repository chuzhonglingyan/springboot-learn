package com.yuntian.webdemo.common;

/**
 * @author guangleilei.
 * @date Created in 14:03 2020/1/13
 * @description
 */
public class Result {
}
