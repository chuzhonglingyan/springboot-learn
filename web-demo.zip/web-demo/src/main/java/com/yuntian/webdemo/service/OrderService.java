package com.yuntian.webdemo.service;

/**
 * @author guangleilei.
 * @date Created in 13:57 2020/1/13
 * @description
 */
public interface OrderService  {


    void  createOrder(Long userId);
}
