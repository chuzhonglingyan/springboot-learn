package com.yuntian.webdemo.service.impl;

import com.yuntian.webdemo.service.OrderService;

/**
 * @author guangleilei.
 * @date Created in 13:57 2020/1/13
 * @description
 */
public class OrderServiceImpl  implements OrderService {


    @Override
    public void createOrder(Long userId) {

    }



}
